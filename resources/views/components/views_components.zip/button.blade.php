<x-filament::button {{ $attributes }}>
    {{ $slot }}
</x-filament::button>