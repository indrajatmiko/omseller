<div class="hidden sm:block" aria-hidden="true">
    <div class="py-5">
        <div class="border-t border-gray-200 dark:border-gray-700"></div>
    </div>
</div>